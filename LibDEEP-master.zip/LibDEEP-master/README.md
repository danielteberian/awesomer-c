# LibDEEP

LibDEEP is a deep learning library developed in C language for the development of artificial intelligence-based techniques.

Please visit our Wiki for all the information needed to work with LibDEEP: https://github.com/jppbsi/LibDEEP/wiki
