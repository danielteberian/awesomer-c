Simple Go demo
==============

Setup
======

Start by installing the simdcomp library (make && make install).

Then type:

go run test.go


