The examples in this directory have been moved a [separate repo][dna-nn].

[dna-nn]: https://github.com/lh3/dna-nn
