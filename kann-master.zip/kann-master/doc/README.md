This directory contains KANN documentations.

* [01user.md](01user.md): for API users

* [02dev.md](02dev.md): for hackers and developers who want to understand the
  internals of KANN.

* 11math.tex (in LaTeX): some math notes.
