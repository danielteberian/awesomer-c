huffandpuff
======

This is an extremely minimal huffman encoder/decoder. It uses no calls at all,
not even stdlib/stdio, making it suitable for embedded applications. The
supplied Makefile will build a test program.

This is in the public domain and is distributed with NO WARRANTY.
