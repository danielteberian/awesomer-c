#!/bin/sh

autoreconf -fi
