#include_next <foo.h>
