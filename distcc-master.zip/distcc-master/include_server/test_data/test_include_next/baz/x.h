Now in baz/x.h
#include_next "x.h"

