#define MSG "hello"
