#include "include_next_foo.h"
